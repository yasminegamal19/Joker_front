import apiClient from "../lib/apiClient";

export const getAdditionalPackages = async () => {
  const response = await apiClient.get("/packages/additional");

  return response.data;
};
