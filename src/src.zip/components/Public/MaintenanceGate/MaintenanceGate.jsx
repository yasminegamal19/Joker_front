// src/components/Public/MaintenanceGate/MaintenanceGate.jsx
import { useAppConfig } from "../../../context/AppConfigContext";

/*
  بيلف الـ Routes كلها. لو maintenance_enabled = true بيعرض صفحة صيانة.
  الستايل inline عشان يشتغل من غير ملف CSS؛ انقله لـ CSS Module لو حبيت.
*/
const MaintenanceGate = ({ children }) => {
  const { config, loading } = useAppConfig();

  if (loading) return null; // أو سبينر لو عندك

  if (config.feature_flags.maintenance_enabled) {
    return (
      <div
        dir="rtl"
        style={{
          minHeight: "100vh",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          gap: "12px",
          padding: "24px",
          textAlign: "center",
        }}
      >
        <img src="/src/assets/logo.png" alt="الجوكر" style={{ height: 56 }} />
        <h1 style={{ fontSize: "1.6rem", margin: 0 }}>
          الموقع تحت الصيانة حاليًا
        </h1>
        <p style={{ margin: 0, opacity: 0.7 }}>
          بنشتغل على تحسينات وهنرجع في أقرب وقت. شكرًا لصبرك.
        </p>
      </div>
    );
  }

  return children;
};

export default MaintenanceGate;
