import { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Menu, UserRound, X } from "lucide-react";
import styles from "./Navbar.module.css";

const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };

    handleScroll();

    window.addEventListener("scroll", handleScroll);

    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  const scrollToSection = (id) => {
    setMenuOpen(false);

    if (location.pathname !== "/") {
      navigate(`/#${id}`);
      return;
    }

    if (id === "home") {
      window.scrollTo({
        top: 0,
        behavior: "smooth",
      });
      return;
    }

    document.getElementById(id)?.scrollIntoView({
      behavior: "smooth",
      block: "start",
    });
  };

  const handleLogin = () => {
    setMenuOpen(false);
    navigate("/choose-user");
  };

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ""}`}>
      <div className={styles.container}>
        <button
          type="button"
          className={styles.brand}
          onClick={() => scrollToSection("home")}
          aria-label="الجوكر - الرئيسية"
        >
          <img
            src="/src/assets/logo.png"
            alt="الجوكر"
            className={styles.logo}
          />
        </button>

        <nav className={`${styles.navLinks} ${menuOpen ? styles.navOpen : ""}`}>
          <button
            type="button"
            className={styles.navLink}
            onClick={() => scrollToSection("home")}
          >
            الرئيسية
          </button>

          <button
            type="button"
            className={styles.navLink}
            onClick={() => scrollToSection("services")}
          >
            خدماتنا
          </button>

          <button
            type="button"
            className={styles.navLink}
            onClick={() => scrollToSection("packages")}
          >
            الباقات والإنترنت
          </button>

          <button
            type="button"
            className={styles.navLink}
            onClick={() => scrollToSection("why-joker")}
          >
            ليه الجوكر؟
          </button>

          <button
            type="button"
            className={styles.navLink}
            onClick={() => scrollToSection("contact")}
          >
            تواصل معنا
          </button>
        </nav>

        {/* Actions */}
        <div className={styles.actions}>
          <button
            type="button"
            className={styles.loginBtn}
            onClick={handleLogin}
          >
            <UserRound size={17} strokeWidth={2} />
            <span>تسجيل الدخول</span>
          </button>

          <button
            type="button"
            className={styles.hamburger}
            onClick={() => setMenuOpen((prev) => !prev)}
            aria-label={menuOpen ? "إغلاق القائمة" : "فتح القائمة"}
            aria-expanded={menuOpen}
          >
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>
    </header>
  );
};

export default Navbar;
