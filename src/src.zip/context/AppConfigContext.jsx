// src/context/AppConfigContext.jsx
import { createContext, useContext, useEffect, useState } from "react";

export const API_URL = (
  import.meta.env.VITE_API_URL || "https://api.elgokar.com"
).replace(/\/+$/, "");

const defaultConfig = {
  banners: [],
  feature_flags: {
    wallet_enabled: false,
    maintenance_enabled: false,
    change_package_enabled: false,
  },
  content_keys: [],
};

const AppConfigContext = createContext({
  config: defaultConfig,
  loading: true,
  error: null,
});

export const AppConfigProvider = ({ children }) => {
  const [state, setState] = useState({
    config: defaultConfig,
    loading: true,
    error: null,
  });

  useEffect(() => {
    const controller = new AbortController();

    const loadConfig = async () => {
      try {
        const res = await fetch(`${API_URL}/app-config`, {
          signal: controller.signal,
          headers: { Accept: "application/json" },
        });

        if (!res.ok) throw new Error(`HTTP ${res.status}`);

        const data = await res.json();

        setState({
          config: {
            banners: Array.isArray(data.banners) ? data.banners : [],
            feature_flags: {
              ...defaultConfig.feature_flags,
              ...(data.feature_flags || {}),
            },
            content_keys: Array.isArray(data.content_keys)
              ? data.content_keys
              : [],
          },
          loading: false,
          error: null,
        });
      } catch (err) {
        if (err.name === "AbortError") return;
        // لو الـ API وقع، الموقع يشتغل بالقيم الافتراضية
        setState({ config: defaultConfig, loading: false, error: err });
      }
    };

    loadConfig();

    return () => controller.abort();
  }, []);

  return (
    <AppConfigContext.Provider value={state}>
      {children}
    </AppConfigContext.Provider>
  );
};

export const useAppConfig = () => useContext(AppConfigContext);






