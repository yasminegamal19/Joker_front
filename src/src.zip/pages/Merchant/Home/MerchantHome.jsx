import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  Activity, ArrowDownLeft, ArrowUpRight, Bell, CreditCard, LayoutDashboard,
  LogOut, Menu, Package, Plus, Search, Settings, ShoppingBag, Store, Users, X,
} from "lucide-react";
import styles from "./MerchantHome.module.css";

const stats = [
  { label: "إجمالي البطاقات", value: "1,284", note: "+12% عن الشهر الماضي", icon: CreditCard, tone: "blue" },
  { label: "البطاقات المباعة", value: "368", note: "+8.4% عن الشهر الماضي", icon: ShoppingBag, tone: "green" },
  { label: "إجمالي المبيعات", value: "24,650 ج.م", note: "هذا الشهر", icon: Activity, tone: "purple" },
  { label: "العملاء النشطون", value: "192", note: "عميل نشط", icon: Users, tone: "orange" },
];

const initialTransactions = [
  { id: "JK-1048", customer: "أحمد محمد", item: "كارت جوكر  20 جنيه", date: "21 أكتوبر 2026", amount: "20 ج.م", status: "مكتملة" },
  { id: "JK-1047", customer: "محمود علي", item: "كارت جوكر  50 جنيه", date: "21 أكتوبر 2026", amount: "50 ج.م", status: "مكتملة" },
  { id: "JK-1046", customer: "سارة إبراهيم", item: "كارت جوكر  10 جنيه", date: "20 أكتوبر 2026", amount: "10 ج.م", status: "قيد التنفيذ" },
  { id: "JK-1045", customer: "مصطفى حسن", item: "كارت جوكر  100 جنيه", date: "20 أكتوبر 2026", amount: "100 ج.م", status: "مكتملة" },
];

const navItems = [
  { label: "الرئيسية", icon: LayoutDashboard, active: true },
  { label: "البطاقات", icon: CreditCard },
  { label: "الباقات", icon: Package },
  { label: "العملاء", icon: Users },
  { label: "المبيعات والعمليات", icon: ShoppingBag },
  { label: "إعدادات المتجر", icon: Settings },
];

export default function MerchantHome() {
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const [query, setQuery] = useState("");
  const transactions = initialTransactions.filter((item) =>
    `${item.id} ${item.customer} ${item.item}`.toLowerCase().includes(query.toLowerCase()),
  );

  const logout = () => navigate("/merchant/login");

  return (
    <div className={styles.dashboard} dir="rtl">
      {menuOpen && <button className={styles.scrim} aria-label="إغلاق القائمة" onClick={() => setMenuOpen(false)} />}
      <aside className={`${styles.sidebar} ${menuOpen ? styles.sidebarOpen : ""}`}>
        <div className={styles.brand}>
          <div className={styles.brandMark}><Store size={23} /></div>
          <div><strong>الجوكر</strong><span>بوابة التاجر</span></div>
          <button className={styles.closeMenu} onClick={() => setMenuOpen(false)} aria-label="إغلاق القائمة"><X size={20} /></button>
        </div>
        <div className={styles.storeCard}><div className={styles.storeAvatar}><Store size={22} /></div><div><strong>متجري</strong><span>حساب تاجر تجريبي</span></div><span className={styles.onlineDot} /></div>
        <p className={styles.navCaption}>القائمة الرئيسية</p>
        <nav className={styles.nav}>
          {navItems.map(({ label, icon: Icon, active }) => (
            <button key={label} className={`${styles.navItem} ${active ? styles.navActive : ""}`} onClick={() => active || window.alert("سيتم تجهيز هذه الصفحة في الخطوات التالية.")}>
              <Icon size={19} /><span>{label}</span>{active && <span className={styles.activeIndicator} />}
            </button>
          ))}
        </nav>
        <div className={styles.sidebarBottom}><div className={styles.helpCard}><span className={styles.helpIcon}>?</span><strong>محتاج مساعدة؟</strong><p>فريق دعم الجوكر جاهز لمساعدتك.</p><button onClick={() => window.alert("سيتم إضافة مركز الدعم لاحقًا.")}>تواصل مع الدعم</button></div><button className={styles.logout} onClick={logout}><LogOut size={18} /><span>تسجيل الخروج</span></button></div>
      </aside>

      <main className={styles.main}>
        <header className={styles.topbar}>
          <div className={styles.topbarStart}><button className={styles.menuToggle} onClick={() => setMenuOpen(true)} aria-label="فتح القائمة"><Menu size={22} /></button><div><span className={styles.breadcrumb}>بوابة التاجر /</span><h1>الرئيسية</h1></div></div>
          <div className={styles.topbarActions}><button className={styles.iconButton} aria-label="بحث"><Search size={19} /></button><button className={styles.iconButton} aria-label="الإشعارات"><Bell size={19} /><i /></button><div className={styles.profile}><div className={styles.profileAvatar}>م</div><div><strong>متجري</strong><span>تاجر</span></div></div></div>
        </header>

        <div className={styles.content}>
          <section className={styles.welcomeRow}><div><p className={styles.overline}>الأربعاء، ٢١ أكتوبر ٢٠٢٦</p><h2>أهلاً بيك في لوحة التحكم 👋</h2><p>تابع نشاط متجرك ومبيعاتك من مكان واحد.</p></div><button className={styles.primaryButton} onClick={() => window.alert("سيتم تفعيل إضافة البطاقات في الخطوة التالية.")}><Plus size={18} /> إضافة بطاقات</button></section>

          <section className={styles.statsGrid} aria-label="ملخص النشاط">
            {stats.map(({ label, value, note, icon: Icon, tone }) => <article className={styles.statCard} key={label}><div className={`${styles.statIcon} ${styles[tone]}`}><Icon size={21} /></div><span className={styles.statLabel}>{label}</span><strong className={styles.statValue}>{value}</strong><div className={styles.statNote}><ArrowUpRight size={14} /><span>{note}</span></div></article>)}
          </section>

          <section className={styles.middleGrid}>
            <article className={styles.panel}><div className={styles.panelHeader}><div><h3>ملخص المبيعات</h3><p>نظرة سريعة على أداء متجرك</p></div><select aria-label="فترة ملخص المبيعات" defaultValue="month"><option value="week">آخر 7 أيام</option><option value="month">هذا الشهر</option><option value="year">هذا العام</option></select></div><div className={styles.salesSummary}><div><span>إجمالي المبيعات</span><strong>24,650 <small>ج.م</small></strong><em><ArrowUpRight size={15} /> 12.8% مقارنة بالفترة السابقة</em></div><div className={styles.chart} aria-label="رسم توضيحي للمبيعات"><div style={{ height: "36%" }} /><div style={{ height: "53%" }} /><div style={{ height: "43%" }} /><div style={{ height: "68%" }} /><div style={{ height: "58%" }} /><div style={{ height: "82%" }} /><div style={{ height: "72%" }} /><div style={{ height: "95%" }} /><div style={{ height: "63%" }} /><div style={{ height: "78%" }} /><div style={{ height: "88%" }} /><div style={{ height: "100%" }} /></div></div><div className={styles.chartLabels}><span>أول الشهر</span><span>منتصف الشهر</span><span>نهاية الشهر</span></div></article>
            <article className={styles.panel}><div className={styles.panelHeader}><div><h3>إجراءات سريعة</h3><p>اختصارات لأهم مهامك</p></div></div><div className={styles.quickActions}><button onClick={() => window.alert("سيتم تجهيز إدارة البطاقات قريبًا.")}><span className={`${styles.quickIcon} ${styles.blue}`}><CreditCard size={20} /></span><span><strong>إدارة البطاقات</strong><small>عرض وإدارة البطاقات</small></span><ArrowDownLeft size={17} /></button><button onClick={() => window.alert("سيتم تجهيز إدارة الباقات قريبًا.")}><span className={`${styles.quickIcon} ${styles.green}`}><Package size={20} /></span><span><strong>إدارة الباقات</strong><small>متابعة الباقات المتاحة</small></span><ArrowDownLeft size={17} /></button><button onClick={() => window.alert("سيتم تجهيز سجل المبيعات قريبًا.")}><span className={`${styles.quickIcon} ${styles.purple}`}><ShoppingBag size={20} /></span><span><strong>سجل المبيعات</strong><small>مراجعة أحدث العمليات</small></span><ArrowDownLeft size={17} /></button></div></article>
          </section>

          <section className={styles.panel}><div className={styles.panelHeader}><div><h3>أحدث العمليات</h3><p>آخر عمليات البيع على متجرك</p></div><label className={styles.tableSearch}><Search size={16} /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="ابحث عن عملية..." /></label></div><div className={styles.tableWrap}><table className={styles.transactionsTable}><thead><tr><th>رقم العملية</th><th>العميل</th><th>المنتج</th><th>التاريخ</th><th>المبلغ</th><th>الحالة</th></tr></thead><tbody>{transactions.map((item) => <tr key={item.id}><td className={styles.transactionId}>{item.id}</td><td>{item.customer}</td><td>{item.item}</td><td>{item.date}</td><td className={styles.amount}>{item.amount}</td><td><span className={`${styles.status} ${item.status === "مكتملة" ? styles.statusDone : styles.statusPending}`}>{item.status}</span></td></tr>)}{transactions.length === 0 && <tr><td colSpan="6" className={styles.empty}>لا توجد عمليات مطابقة للبحث.</td></tr>}</tbody></table></div><div className={styles.tableFooter}>بيانات تجريبية للعرض — سيتم ربطها بالـ Backend لاحقًا.</div></section>
          <footer className={styles.footer}>© 2026 الجوكر للإنترنت والخدمات الرقمية</footer>
        </div>
      </main>
    </div>
  );
}
